System.out.println("Hello, World!")
int a = 13;
System.out.println(a)
void main(String[] args){
System.out.println("Hello, World");
}
main(null)